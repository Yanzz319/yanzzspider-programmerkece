
document.addEventListener('DOMContentLoaded', ()=>{
  // year
  document.getElementById('year').innerText = new Date().getFullYear();

  // language buttons (simple toggles - content static in this version)
  document.querySelectorAll('.lang-btn').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      document.querySelectorAll('.lang-btn').forEach(b=>b.classList.remove('active'))
      btn.classList.add('active')
      // optional: switch language content (left as static for now)
    })
  })

  // audio controls
  const bg = document.getElementById('bgMusic')
  const whoosh = document.getElementById('whoosh')
  const soundBtn = document.getElementById('soundToggle')
  let musicPlaying = false

  function setSoundIcon(on){
    soundBtn.innerText = on ? '🔊' : '🔈'
    soundBtn.setAttribute('aria-pressed', on ? 'true' : 'false')
  }

  soundBtn.addEventListener('click', ()=>{
    if(!musicPlaying){
      bg.volume = 0.35
      bg.play().catch(()=>{})
      musicPlaying = true
      setSoundIcon(true)
      whoosh.play().catch(()=>{})
    } else {
      bg.pause()
      musicPlaying = false
      setSoundIcon(false)
    }
  })

  // play whoosh when clicking hero actions
  document.querySelectorAll('.hero-actions .btn').forEach(b=>{
    b.addEventListener('click', ()=>{ whoosh.currentTime = 0; whoosh.play().catch(()=>{}) })
  })

  // subtle canvas glow
  const canvas = document.getElementById('glow-canvas')
  const visual = document.querySelector('.hero-visual')
  if(canvas && visual){
    canvas.width = visual.clientWidth
    canvas.height = visual.clientHeight
    canvas.style.position = 'absolute'; canvas.style.left = 0; canvas.style.top = 0; canvas.style.zIndex = 0; canvas.style.pointerEvents='none'
    const ctx = canvas.getContext('2d')
    function draw(){ 
      ctx.clearRect(0,0,canvas.width,canvas.height)
      const grad = ctx.createRadialGradient(canvas.width*0.78, canvas.height*0.18, 10, canvas.width*0.78, canvas.height*0.18, Math.max(canvas.width,canvas.height))
      grad.addColorStop(0, 'rgba(227,59,59,0.18)')
      grad.addColorStop(0.5, 'rgba(227,59,59,0.06)')
      grad.addColorStop(1, 'rgba(0,0,0,0)')
      ctx.fillStyle = grad
      ctx.fillRect(0,0,canvas.width,canvas.height)
      // subtle moving web lines
      ctx.strokeStyle = 'rgba(255,255,255,0.03)'
      ctx.lineWidth = 1
      for(let i=0;i<8;i++){
        ctx.beginPath()
        const x = canvas.width * (0.2 + 0.1*i)
        ctx.moveTo(x,0)
        ctx.lineTo(canvas.width*0.5, canvas.height*0.6 + 6*Math.sin((Date.now()/600)+i))
        ctx.stroke()
      }
    }
    draw()
    setInterval(draw, 120)
    window.addEventListener('resize', ()=>{ canvas.width=visual.clientWidth; canvas.height=visual.clientHeight; draw() })
  }

  // send button feedback
  const sendBtn = document.getElementById('sendBtn')
  if(sendBtn) sendBtn.addEventListener('click', ()=>{
    sendBtn.innerText = 'Sent ✓'
    setTimeout(()=> sendBtn.innerText = 'Kirim Pesan', 1400)
  })
})
